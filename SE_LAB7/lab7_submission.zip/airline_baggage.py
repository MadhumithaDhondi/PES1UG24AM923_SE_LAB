import math


def parse_booking(code):
    """Parse 'AI-203-12A' -> ('AI', 203, 'A').

    Returns None for any invalid or unexpected input instead of crashing.
    """
    if not isinstance(code, str):
        return None
    parts = code.strip().split('-')
    if len(parts) != 3:
        return None
    airline, flight, seat = (p.strip() for p in parts)
    # Airline: 2-3 ASCII letters/digits
    if not (2 <= len(airline) <= 3 and airline.isascii() and airline.isalnum()):
        return None
    # Flight: 1-4 ASCII digits (isdigit alone accepts '²', which int() rejects)
    if not (1 <= len(flight) <= 4 and flight.isascii() and flight.isdigit()):
        return None
    # Seat: row number followed by a single letter, e.g. '12A'
    if not (2 <= len(seat) <= 3 and seat.isascii()
            and seat[:-1].isdigit() and seat[-1].isalpha()):
        return None
    return airline.upper(), int(flight), seat[-1].upper()


def total_weight(weights_csv):
    """Sum comma-separated bag weights in kg, e.g. '12.5,7,23' -> 42.5.

    Returns None if the input is not a string, has empty/non-numeric values,
    or contains negative, NaN or infinite weights.
    """
    if not isinstance(weights_csv, str):
        return None
    total = 0.0
    for w in weights_csv.split(','):
        w = w.strip()
        if not w:
            return None
        try:
            value = float(w)
        except (ValueError, OverflowError):
            return None
        if not math.isfinite(value) or value < 0:
            return None
        total += value
    if not math.isfinite(total):
        return None
    return total


def tag_label(name):
    """'Ravi Kumar' -> 'R. KUMAR'. Uses the first and last name given.

    Returns None if the input is not a string or has fewer than two names.
    """
    if not isinstance(name, str):
        return None
    parts = name.split()
    if len(parts) < 2:
        return None
    return parts[0][0].upper() + '. ' + parts[-1].upper()


def main():
    print("==== Running parse_booking ====")
    user_input = input("Enter a booking code (e.g. AI-203-12A): ")
    result = parse_booking(user_input)
    if result is None:
        print("Invalid booking code. Expected format like AI-203-12A.")
    else:
        print("Airline, Flight and Seat Letter:", result)

    print("\n==== Running total_weight ====")
    user_input = input("Enter bag weights in kg as CSV (e.g. 12.5,7,23): ")
    result = total_weight(user_input)
    if result is None:
        print("Invalid weights. Enter non-negative numbers separated by commas.")
    else:
        print("Total Weight:", result)

    print("\n==== Running tag_label ====")
    user_input = input("Enter a passenger name (first and last): ")
    result = tag_label(user_input)
    if result is None:
        print("Invalid name. Enter at least a first and a last name.")
    else:
        print("Tag Label:", result)


if __name__ == "__main__":
    main()
