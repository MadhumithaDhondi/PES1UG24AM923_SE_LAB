"""Lab 7 - Fuzz testing airline_baggage.py with Hypothesis.

Each function gets:
  1. a "no crash" fuzz test on random text / None (any exception is a bug),
  2. a fuzz test on other random Python types,
  3. a property test on generated VALID input (correct result is returned).
Invalid input must be rejected gracefully by returning None.

Every property-based test below runs 5,000 generated examples
(@FUZZ_SETTINGS = settings(max_examples=5000)).

Run:  pytest test_airline_baggage.py
"""
import math
import string

from hypothesis import given, settings, strategies as st
from airline_baggage import parse_booking, total_weight, tag_label

# Run each property-based test with 5,000 generated inputs
FUZZ_SETTINGS = settings(max_examples=5000)

# Random junk of many types, not just strings
any_input = (
    st.text() | st.none() | st.integers() | st.floats()
    | st.booleans() | st.lists(st.text()) | st.binary()
)


# ---------------- parse_booking ----------------

@FUZZ_SETTINGS
@given(st.text() | st.none())
def test_parse_booking_no_crash(s):
    try:
        result = parse_booking(s)
    except Exception as e:
        assert False, f"parse_booking crashed with: {e!r}"
    assert result is None or isinstance(result, tuple)


@FUZZ_SETTINGS
@given(any_input)
def test_parse_booking_any_type_no_crash(s):
    try:
        parse_booking(s)
    except Exception as e:
        assert False, f"parse_booking crashed with: {e!r}"


@FUZZ_SETTINGS
@given(
    airline=st.text(alphabet=string.ascii_letters, min_size=2, max_size=3),
    flight=st.integers(min_value=1, max_value=9999),
    row=st.integers(min_value=1, max_value=60),
    letter=st.sampled_from("ABCDEFabcdef"),
)
def test_parse_booking_valid_codes(airline, flight, row, letter):
    code = f"{airline}-{flight}-{row}{letter}"
    assert parse_booking(code) == (airline.upper(), flight, letter.upper())


# ---------------- total_weight ----------------

@FUZZ_SETTINGS
@given(st.text() | st.none())
def test_total_weight_no_crash(s):
    try:
        result = total_weight(s)
    except Exception as e:
        assert False, f"total_weight crashed with: {e!r}"
    # A total weight must be a real, finite, non-negative number (or rejected)
    assert result is None or (math.isfinite(result) and result >= 0)


@FUZZ_SETTINGS
@given(any_input)
def test_total_weight_any_type_no_crash(s):
    try:
        total_weight(s)
    except Exception as e:
        assert False, f"total_weight crashed with: {e!r}"


@FUZZ_SETTINGS
@given(st.lists(st.floats(min_value=0, max_value=100, allow_nan=False),
                min_size=1, max_size=10))
def test_total_weight_valid_csv(weights):
    csv = ",".join(repr(w) for w in weights)
    assert math.isclose(total_weight(csv), sum(weights), abs_tol=1e-6)


@FUZZ_SETTINGS
@given(st.floats(allow_nan=True, allow_infinity=True) | st.floats(max_value=-0.001))
def test_total_weight_rejects_bad_numbers(w):
    # nan, inf and negative weights are not valid bag weights
    if not math.isfinite(w) or w < 0:
        assert total_weight(str(w)) is None


# ---------------- tag_label ----------------

@FUZZ_SETTINGS
@given(st.text() | st.none())
def test_tag_label_no_crash(s):
    try:
        result = tag_label(s)
    except Exception as e:
        assert False, f"tag_label crashed with: {e!r}"
    assert result is None or isinstance(result, str)


@FUZZ_SETTINGS
@given(any_input)
def test_tag_label_any_type_no_crash(s):
    try:
        tag_label(s)
    except Exception as e:
        assert False, f"tag_label crashed with: {e!r}"


@FUZZ_SETTINGS
@given(
    first=st.text(alphabet=string.ascii_letters, min_size=1, max_size=12),
    last=st.text(alphabet=string.ascii_letters, min_size=1, max_size=12),
)
def test_tag_label_valid_names(first, last):
    assert tag_label(f"  {first}   {last} ") == f"{first[0].upper()}. {last.upper()}"
